
function Student(id, name, age) {
	this.id = id;
	this.name = name;
	this.age = age;

	this.alertInfo = function() {
		alert(this.name + ' ' + this.age + ' ' + this.id);
	}
}

var student1 = new Student(1, 'Sandra', 28);
//student1.alertInfo();

var student2 = new Student(2, 'Emilija', 28);
//student2.alertInfo();


var width = 600;

function showWidth() { 
	console.log(this.width);
}

//showWidth();//'this' will be window object

student1.showWidth = showWidth;
student1.showWidth();//'this' will be student1

student2.showWidth = showWidth;
student2.showWidth();//'this' will be student2

/*
var searchedProperty = 'name1';
var hasProperty = false;
for (var property in student) {
	if (property === searchedProperty) {
		console.log('student Object has the property ' + searchedProperty);
		hasProperty = true;
		break;
	}
}

if (!hasProperty) {//(hasProperty === false) {
	console.log('student Object does not have the property ' + searchedProperty);
}
*/

/*var searchedProperty = 'age';
if (student.hasOwnProperty(searchedProperty)) {
	console.log('student Object has the property ' + searchedProperty);
} else {
	console.log('student Object does not have the property ' + searchedProperty);
}*/