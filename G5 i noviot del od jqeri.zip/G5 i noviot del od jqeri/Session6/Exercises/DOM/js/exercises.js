//first
// let myHeader = document.getElementById('myTitle');
// console.log(myHeader);
// console.log(myHeader.textContent)

//second
// let myDivs = document.getElementsByClassName('myDiv');
// console.log(myDivs);

// for (let i = 0; i < myDivs.length; i++) {
// 	console.log(myDivs[i]);
// }

//third
// let pElements = document.getElementsByTagName('p');

// console.log(pElements);
// pElements[0].textContent = 'Changed content of first paragraph';
// //pElements[100].textContent = 'asdasd'; error

// for (let i = 0; i < pElements.length; i++) {
// 	console.log(pElements[i].textContent);
// }

//fourth
// let pElements = document.querySelectorAll('p');
// console.log(pElements);
// let firstPElement = document.querySelector('p'); 
// console.log(firstPElement);

// let pElementsWithSomeClass = document.querySelectorAll('p.myParagraph');
// console.log(pElementsWithSomeClass[0].textContent);

 let pWithSomeId = document.querySelector('#firstP');
 //console.log(pWithSomeId.textContent);

 let previousSibling = pWithSomeId.previousElementSibling;
 //console.log(previousSibling.textContent);

 let parentOfP = pWithSomeId.parentElement;
 //console.log(parentOfP.textContent);

 let childrenOfParentOfP = parentOfP.children;
 console.log(childrenOfParentOfP);

