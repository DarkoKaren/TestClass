// function first()
// {
//     setTimeout( function(){
//         console.log(1);
//     },500);
// }
// function second()
// {
//     console.log(2);

// }
// first();//pecati prven dva pa eden radi tajmerot od edna sekunda 500
// second();


// //simple callback

// function doHomework(subject,callback){
//     alert(`Starting my ${subject} homework1`);//za da fiunkcionira dolarot mora da se napisat ovie ` ` koi ni se do edinicata na stataturata
//     let num = Math.ceil(Math.random() * 10);
//     callback(num);

// }
// doHomework('math',function(time){
//     alert(`Finished my homwork is ${time} sec`);
// });


//logger callback

var allUserDate=[];

function logStuf(userDate){
    if (typeof userDate ==='string')
    {
        console.log(userDate);
    }
    else if(typeof userDate ==="object")
    {
        for(var item in userDate)
        {
            console.log(item+":"+userDate[item]);
        }
    }
}
function getInput (options,callback)
{
allUserDate.push(options);
callback(options);
}
getInput({name:"Rich",speciality:"JavaScript"},logStuf);


///

function one()
{
    
}
    function tow()
    {

    }
        function three()
        {
            three();
        }
            function four()
            {
                four();
            }
                function five()
                {
                    five();
                }
            