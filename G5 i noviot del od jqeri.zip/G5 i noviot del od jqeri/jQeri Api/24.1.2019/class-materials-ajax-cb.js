function successCallback()
{
    //do stuuff before send 
}
function successCallback()
{
    //do stuff if success message received
}
function completeCallback()
{
    //do stuuff upon  completion 
}
function errorCallback()
{
    //do stuuff is error received 
}
$.ajax({
    url:"http://fiddle,jshell.net/favicon.pug",
    success:successCallback,
    complete:completeCallback,
    error:errorCallback,
    onBeforeSend:onBeforeSendCallback
});