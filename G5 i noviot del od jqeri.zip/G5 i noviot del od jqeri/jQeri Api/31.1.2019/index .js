//ecampl a
var cata={name:'Fluffy', color:"Ehite", age:0};
var  catB={name:'Fluffy', color:"Ehite", age:0};
cata===catB//false - typeof prototype of cata=cata prototype
//typeof prototype of catB=CatB prototype

//example B

var catB=object.create(new object());

catB.name="fluffy";
catB.color="White";
catB.age=0;


//exemple c

function cat (name,color){
    this.name=name;
    this.color=color;
}//this koa go koristime potencirame deka i konstruktorot ke go koristime toj konstruktor
cat.prototype.age=0;

var cat= new  cat("Fluffy","White");

//inheritance and chain

function Mammal()
{
    this.bloodTemp='warm';
    // this.growHair=function(){ console.log('my hir is growing')}
}

function Carnivore()
{

}
function lion(name)
{
    Mammal.call(this);//super. Inherit constructor
    this.name=name;
}
Mammal.prototype.growHair= function(){
    console.log('my hir is growing')
}
Carnivore.prototype=object.create(Mammal.prototype);

Carnivore.prototype.eatMeat=function(){
    console.log('mm.meat');
}
lion.prototype.pride=function(){
    console.log('im king of the jungle');
};


var charlie = new lion('charlie')

charlie.growHair();//my hair is growing
charlie.eatMeat();//Mmm.meat
charlie.pride();//im king of the jungle
charlie.bloodTemp//warm


//Extend existing construction functions whit following properties
/*
pepole to be able to have a color of eyes and hair, and to be or get over function(e.g Fly.sound)

create new different instances of people and assing values to the form
color of hair and eyws.

make the pepole live ,give the to eat and return status that they
had eten.

put all people in array and print them on screen using CSS from styling
to color their hair and eyes (on screen) end to show their status
of eaten or not.
*/

//CSSTricks https://css-tricks.com/