//literal in javascript 
let obj1={
    "name":"Some Name",
    "id":1
}
//obj1.name -- Som Name
//obj1.id-----1
//se stavaat vo string " " za da moze da se procitaat onaka kako sto sakame
//dali e brojka ili razdvoeno pisano
//obj1["1"] work
//obj1.1 not work

for (let i in obj1)
{
    console.log(i);//i-is the name of the key
    console.log(obj1[i]);//valu of the key
}
obj1.age=30;
obj1.city='Skopje';


//Entites mapped object

let person={
    frstName:false,
    lastName:false,
    age:false,
    height:false
}
for(let code  in cods)
{
    alert (code);//1,41,44,49
}
//always asc
let code={
    '49':"germany",
    "41":"Switerland",
    '1':"USA"
}
//resorted
let newCode={
    "0":
    {
        prefix: 49,
        country:"Germany"

    },
    '1'{
    prexix:41,
    country:"Switerland"
    }
}
//get key and get values form object

let keyArray = Object.keys(prefixByContry);//['germani','swe','usa']
let valuesArray=Object.values(prefixByContry);//['1',''41','49']

let newSwap={}
for(let i=0;i<valuesArray.length;i++)
{
    newSwap[valuesArray[i]]=keyArray[i];
}

//clone - copy of object

let object2={
    a:5,
    b:10
}
let object3=object2;
//deep clone - same look different proto

 let object4=JSON.parse(JSON.stringify(object2));

 JSON.stringify(object2) => "{'a','5','b':'10'}";

 JSON.parse("{'a','5','b':'10'}");

 //Function as values
 let object5={
     set:10,
     getStartPosition:function()
     {
         return 10;
     }
     setNewPosition:function(position)
     {
         this.step=position;
      }
      setheight:function(height)
      {
          this.frstName=name;
      }
      setLastname:function(name)
      {
          this.lastName=name;
      }
 
 
}
personMap.setAge(344);
personMap.setHeight(400);
personMap.setName('peter\'s grandFather');
personMap.setLastname("highlander");

//personMap.callExternal(n);
let peter=JSON.parse(JSON.stringify(personMap));

personMap.setAge(344);
personMap.setHeight(400);
personMap.setName('peter\'s grandFather');
personMap.setLastname("highlander");

let peterGF=JSON.parse(JSON.stringify(personMap));

//other way to define object
let nObj=new object();//{}

let cObj=new Object(nObj);//{} - clone of nObj

//create- copy object 
let o6 = object.create({});//object.create(object propertype, properties)
//assing
let o7 = object.assing(); //object.assign ({1},{2},{3});

let o71={
    a:1,
    b:2,
    c:3
}
let newObject=Object.assign({c:10,b:4},o71);




// make new form in HTML where you will enter person name lastname,age and height
// use personMap from create object form the form date and assing value to a array of objects

// homwork make possibility each stored person to be loaded in the form and edited by user.

let personMap={
    
}