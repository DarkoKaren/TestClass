// function nameFn(){
// return 1+2;
// }
// //anonimna funcija
// let fuName= function(){
//     return 1+2;
// } 
//  nameFn();// gi povikuvame funkciite
//  fnName();//anonimnata funkcija ja povikuvame

// //objekt koj ima vo svoeto telo properti koja ima vrednost funkcija
//  let objectName={
//       thisIsRandomFunction: function(){}  //zivee samo vo varijablata nadvor od nea ne 
//  }
//  // ziveat vo {} zagradi samo 
//  // koga e nonstrit  moze da pratime 3 ili pomalku od niv 
//  //za strit se ocekuva samo 3 parametri da procita ne poveke 
//  function functionWithParametar(a,b,c){}

//  var timesTow=function(number){
//      return number * 2;
//  };
//  timesTow(4);//cisti funkcii sto samo mnozi so 2

//  var multiplier=5;
//  var timesTow=function(number){//brojot na parametri ne odreduva kakov ke bide rezultatot
//     return number * multiplier;
// };// ne se cisti funkcii  bidejki moze da se smeni vo kodot

// /*
// Arrow Function
// */
// var materials=[
//     "dsasad"
//     "sadsads"
//     "fdsfdsa"
//     "gfdsfgf"
// ];
// console.log(materials.map(materials => matirial.length));//=> eror function 

// function materialLength(material)
// {
//     return material.length;
// }
// let resilt=[];
// for( let i=0;i< materials.length;i++)
// {
//     resilt.push(materialLength(materials[i]));
// }
// console.log(result);

// (param1,param2,...)=>{
//     //statement

// }

// (param1,param2)=> return 1;//nemaat svoe telo nemaat parametri
// param1=> return 2; // nemoze da se koristi ovaka
// //ocekuvanoe e da se ima
// (param1)=> return param1.json();

// fetch('http://jasonplablabla')
// .then(data=>data.jeson())
// .then(data=> console.log(data))


// (async()=>{
//     let response= await fetch('fdsadsfsad')
//     let data= await response.json();
//     console.log(data)
// })


// //Spread Syntax


// function one(a,b,c)
// {

// }
// let numbers=[1,2,3]
// function two(...args)
// {
//  console.log(args);
// }
// two (numbers);


// one([1,2,3])



// //Scop
// //teo typs
// //local scope
// //global scope

// let thisisGlobalVariable =10;
// //window.thisisGlobalVariable=10;
// funtion calcVariables(a,b)
// {
//     return a+b+thisisGlobalVariable;
// }
// //window.calcVariables= function(a,b){}
// function executeCalc()
// {
//     calcVariables(5,10);
// }

// function functionWithParametar(a,b)
// {
//     let c=10;
//     let that=this;//this is this of perentfunction()
//     function calcResult(a,b,c)//se izvrsuva vnatre nadvor od nea ne postoi
//     {
        
//         return a+b+c+ thisisGlobalVariable;
//     }
//     function b(){
//         let v;
//         let that=this;//this is this of b()
//         function c()
//         {
//          that.calcResult(1,2,3);
//         }
//     }
//     console.log(this.calcResult());
//     return calcResult();
// }
// let a=2;
// let b=2;
// function calc(a,b)
// {
//     return a*b;
// }
// let a=2;
// let b=2;
// let c=2;
// function tre(a,b,c)
// {
//     return a*b*c;
// }
//zadaca 1
//calculet number on exponencijal wiht pure function
//2 exp 2=4 , exp 3=8
//n2=N*N , n3=N*N*N;
function exponential(a,n)
{
    let result=1;
    for(let i=1;i<=n;i++)
    {
        return=a*result;
    }
    return result; 
}
exponential(2,3)

//2 clean  the array from non integer valuse
const dataToClean =[1,NaN,2,3,NaN,'',5];
//[1,2,3,5]

function cleanUp(arrayOfItems)
{
    let clean=[];
    for(let i=0;i<arrayOfItems.length;i++)
    {
        if(arrayOfItems[i]/arrayOfItems[i]===1)
        {
            clean.push(arrayOfItems[i])
        }
    }
    return clean;
}

//3nd takse clean  the array from non integer valuse
const dataToClean=[1,NaN,2,[3,NaN,'',5]];
//[1,2,3,5]

// 4rd get maximum time from arry from any 4 valuse between 0-9
// [1,2,3,4] input expected output 23:41 23 hours and 41 minutes
// mnozestvo od bilo koi 4 cifri  na vlez na saaat da e najgolemata vrednost od 0 do 9
// od 4 cifri  kombinacii
// combinacii da se pomali od  23 59 i gi isfrlas od najgolema do najmala vrednost 
let arr=[1,2,3,4]//0-9
function timeCalc(arr)
{
    

    
}