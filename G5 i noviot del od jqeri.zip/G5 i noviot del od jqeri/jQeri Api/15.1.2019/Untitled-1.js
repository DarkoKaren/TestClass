//array, applied to js arrays[].map();

//map
var array1=[1,4,9,16];
let array2=array1.map(x=>x*2);
console.log(array2);

/* inside map

for(let i=0;i<array1.lenght;i++)
{
    array2.push(array1[i]*2);
}
return array2;
*/


let array3=array1.map((x)=>{
    function multiply(a,b)
    {
        return a*b;
    }
    if(x>4)
    {
        return multiply (x,2);
    }
});

function multiply(x)
{
    return x*2;
}
let array4=array1.map((x)=>multiply(x));





//concat
// da spoime 2 raboti

let array1=['a','b','c'];
let array2=['d','f','e'];
console.log(array1.concat(array2));
//["a", "b", "c", "d", "f", "e"] dobivame 
//let array3=array1.concat(array2);

//fill
//avtomacki gi popolnuva  vrednostite 

let array1=[1,2,3,4,5,6,7];//array1=Array.fill();
//Array.fill(start_index,end_index);
array1.fill(0,3,5);
//pecati [1,2,3,0,0,6] idex na pozicija 3 dodava nulii i gleda dali e pomalo ili pogolemo od 5 za toa dava 6 

array1.fill((x)=>{
    return x*2;
},0,2);

//filter
var words=['spray','limit','elite','exuberant','destruction','present'];
const result =wprds.filter((item,i)=>item.lenght>6);
console.log(result);

//find
var array1=[5,12,8,130,44];
var found=array1.find(function(element,i){ //slicno kako na for ciklusot
    return element>10;
});


//forEach
//za sekoj element vo nizata
var array1=['a','b','c'];
array1.forEach((element)=>{
    console.log(element);
});
//join
//edna niza da ja vratite vo string 
var element=['fire','wind','Rain'];
console.log(element.join());//sleano spoeni so  zapirki samo fire,wind,rin
console.log(element.join(''));//odvoeni
console.log(element.join('-'));//so crta

let uri=['http://api.endpoint.com','todos',1];
uri.join("/");
//pecati http://api.endpoint.com/todos/1]

//keys
//ni gi vraka pointerite 
var array=['a','b','c'];
var iterator=array.keys();
for(let key of iterator){
    console.log(key); //pecati 0,1,2
}
//push
//sekogas dava po eden nov
var animals=['pigi','manke','tayga'];
console.log(animals.push('cows'));

//pop
//posledniot element vo nizata 
var plans=['adsd','asdasd','asdas'];
console.log(plans.pop());

//splice
//
var monts=['jan','march','april'];
//monts.splitce(startIndex,deketeCount,items)
monts.splice(1,0,'feb');
//ke vrati jan , march , april

monts.splice(4,1,'march');
//ke vrati jan , march , april

//indexOf
//na koj index se vraka soodvetna vrednost

var  beasts=['ant','bison','camel','duck','bison'];
console.log(beasts.indexOf('bison'));
console.log(beasts.indexOf('bison',2));//2 is startfrom or start index for forloop
console.log(beasts.indexOf('giraffe'));//-1

//reduce
//smaluvanje na nizata 

const array=[1,2,3,4];
console.log(array.reduce((accumulator,currentValue) => accumulator+currentValue));
//ocekuvana vrednost od ova e 10 
//1+2=3  3+3=6 6+4=10