Math.random()//generiranje po slucaen izbor , nikogas ist kako predhodniot broj

Math.min()//minimalna vrednost 

Math.max()//najgolemata vrednost
// site ovie rabotat so integer

'${variableName}'
'<li>'+variableName+'</li>';
`<li>${variableName}</li>`//Es6 alternative gor the libe above

'</li>\
<span>'+variableName+'</span>\
</li>'


`</li>\
<span>${variableName}'</span>\
</li>
`

Let a=5, b=10;
`the result is :${a+b}`;

Math.random()//generiranje po slucaen izbor , nikogas ist kako predhodniot broj

function randomNumber()
{
    return Math.random();
}
function generateRandomNumber(min,max)
{
    return Math.random()*(max-min)+min;
    // generateRandomNumber(10,30) ,
    //Math.floor( generateRandomNumber(10,30));-zaokruzuva na decimala
    //,Math.ceil( generateRandomNumber(10,30));-cel broj zima
}

Math.min()//minimalna vrednost 

Math.min(10,31,2);
//2
Math.min(-10,-32,-1)
//-32

Math.max()//najgolemata vrednost


Math.max()
//-infinity

Math.max(10,2,nan)
//nan

Math.max(1,2,3,4)
//4

Math.max(1,2,3,nan)
//nan


let numbers=[1,2,3,4];
Math.max.apply(null,number);
//4
Math.min.apply(null,number);
//1

//Recursion

//factoriel of 5 is 5x4x3x2x1.

function factoriel(n){
    if(n===1){
        return 1;
    }
    return n*factoriel(n-1);
}

function something()
{
    if(i===10)
    return 1;
    
    if(i===100)
    return 10;

    if(i===200)
    return 20;
}

//Anonymous function

let  multiply=function(x,y)
{
    return x*y;
}
multiply(2,3);//6


//Impure function

let tax=18;
function calculateTa(amount)
{
    return ((amount*tax)/100)+productPrice;
}



//closutes

function printBrowserName()
{
    let name='Mozilla'
    function alertName()
    {
        alert(name);
    }
    return alertName;//ako e alertName() vaka samo ednas ke se izvrsi i potoa nemoze da se izvrsi 
}

let tmpFunction=printBrowserName();
tmpFunction();

/*
let name='';
function printBrowserName()
{
    let name='Mozilla'
}
    function alertName()
    {
        alert(name);
    }
    printBrowsweName();
    alertName();
    


*/


//strict /nonstrict

//default nonstrict;

var undifined=5;
//undifined vraka

function test(a)
{
    return a*10;

}
//nan not a namber

'use strict';

'use strict';
var  undifined =5;
//eror


var obj1={};
object.defineProperty(obj1,'x',{value:42,writable:false});
//{x:42} 
//obj1.x=3;
// 3

//ili
var obj1={};
object.defineProperty(obj1,'x',{value:42,writable:true});
//obj1.x=3;
//obj1.x;
//3

