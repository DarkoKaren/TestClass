/*use the following html code below ,by using js apply table style sorttabel.
When user click on one one of the headers (under tr class="heding") the table should sort by that fild
*/

function getTabletTitle()
{
    let title=document.querySelector('.title');
    title.setAttribute('style','background:#CACACA; font-familly:Arial; font-size:18px;');

    document.querySelector('title>td').setAttribute('style','padding:10px');
}
function colorHeading(heding)
{
    heding.setAttribute('style','background:#EFEFEF; font-size:14px; font-family:Arial; font-weight:bold;');
}
function getHeading()
{
    let hedings=document.querySelectorAll('.heading');
    colorHeadings(headings);
}
function getHeadingTitle()
{
    let  titles=document.querySelector('.heding>td');
    styleHedingTitles(titles);
    applyClickEventsOnHeadingTitles(titles);
}
getTabletTitle();
getHeading();