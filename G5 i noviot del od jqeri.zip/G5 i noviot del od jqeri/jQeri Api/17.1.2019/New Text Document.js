/*use the following html code below ,by using js apply table style sorttabel.
When user click on one one of the headers (under tr class="heding") the table should sort by that fild
*/