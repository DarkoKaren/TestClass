/*
mostFrequentItem
White a JavaScript program to find the most frequent item of an array.

Sample array: let arra1=[3,'a','a','a',2,3,'a',3'a',2,4,9,3];
simple output:a(5 times)
*/

var arra1=[3,'a','a','a',2,3,'a',3,'a',2,4,9,3]
var mf=1;
var m=0;
var item;

for(var i=0;i<arra1.length;i++)
{
    for(var j=i;j<arra1.length;j++)
    {
        if(arra1[i]==arra1[j])
        m++;
        if(mf<m)
        {
            mf=m;
            int=arra1[i];
        }
    }
    m=0;
}
console.log(item+"("+mf+"tims)");


/*let arra1=[3,'a','a','a',2,3,'a',3,'a',2,4,9,3]
// let mostFrequentItem=1;
//let MomentalItem=0;
//let itemItself;

//for(let i=0;i<arra1.length;i++)
//{
    //for(let j=;j<arr1.length;j++)
   {
       if(arra1[i]===arra1[j])
       {
           momentalItem++;
       }
       if(mostFrequentItem < momentaliItem)
       {
           mostFrequentItem=momentaliItem
           ItemItself=arra1[i];
       }
   } 
   momentaliItem=0;
 */   
 //}
//console.log('the most frequent item is :${itemItSelf}-it has${mostFrequentItem}like him in array');

// write a JavaScript function to find the difference of two arrys.
// a1=[1,2,3] , a2=[100,2,1,10])
// exected resull:[3,10,100]


function differenceOf2Arrays (array1, array2) {
    const temp = [];
    array1 = array1.toString().split(',').map(Number);
    array2 = array2.toString().split(',').map(Number);
    
    for (var i in array1) {
    if(!array2.includes(array1[i])) temp.push(array1[i]);
    }
    for(i in array2) {
    if(!array1.includes(array2[i])) temp.push(array2[i]);
    }
    return temp.sort((a,b) => a-b);
    }
    
    console.log(differenceOf2Arrays([1, 2, 3], [100, 2, 1, 10]));
    console.log(differenceOf2Arrays([1, 2, 3, 4, 5], [1, [2], [3, [[4]]],[5,6]]));


    