//Very basic sytax
class ClassName
{
    /*......*/
}

//Constructor
const Dog= function(name,breed){//moze i vaka da se pise 
    this.name=name;

    this.breed=breed;
    this.getDogName()
};
Dog.prototype.getDogName=function(){
    return this.name;//ke javi greska bidejki ne e kreirano gore takvo get dog name
}

class Dog//ova e clasa sto treba da se koristi vaka no moze kako i gore sto e const dog
{
    constructor(name,breed)
    {
        this.name=name;
        this.breed=breed;
    }
    getDogName(){
        return this.name;
    }
    setDogName(newName)
    {
        this.name=newName;
        return true;

    }
}

let dog1=new Dog('Jonny','Corgie');

dog1.setDogName('Tobi');


//Encapsulate

const Dog=(name,breed,sound)=>{
    const bark=()=> console.log(sound); //erol fanktion e( => ) ova
    return{
        name,breed,bark
    };
}

class User
{
     constructor()
     {
         this.name="usernam";
         this.lastname="userlastnam";.
         this.email="user@email.com"
     }
} 


//Composition
const dog ={
    name:'Fido',
    breed:'Collie',
    collar:{
        color:'red',
        shape:'pendant'
    },
    tail:{
        lenght:{
            valu: 10,
            unit:'cm'
        },
        status:'wagging'
    }
};


//Constructor functions

const collar=({shape='oendant', color='blue'})=>{
    return {
        shape,
        color
    };
};
const Lenght=({value=0,unit='cm'})=>{

    return{
        value,
        unit
    };
};

const tail=({tailLength,status})=>{
    return{
        lenght,
        status
    };
};

const Dog=(name,breed,sound)=>{
    const bark=()=> console.log(sound);
    const tail=Tail({
        tailLenght:10,
        status:'Wagging'
    });
    const collar=collar({color:'red'});
    return{
        name,breed,bark,tail,collar
    };
}

const dog = Dog('Fido','Collie','Grrr');

class Lenght()
{
    constructor(valu,unit)
    {
        this.lenght=new length(length);
        this.status=status;
    }
}

class color()
{
    constructor(name,breed,sound)
    {
        this.name=name;
        this.breed=breed;
        this.bark=console.log(sound);

        this.tail=new tail(10,'wagging');
        this.collar=new collar('red');
    }

    setNewLength(amount)
    {
        this.tail=new tail(amount);
    }
}

let dog2=new dog('fido','collie','grrrr');

dog2.tail.lenght=144;

//Polymorphism

const Animal=function(sound){
    this.sound=sound;
};

Animal.prototype.makeSound=function(){
    console.log(this.sound);
};

const Dog=function(name,breed){
    this.name=name;
    this.breed=breed;
}
Dog.prototype=new Animal('weow');

const dog=new Dog('Fido','Collie');
const cat=new cat('Oliver','Siamese');


dog.makeSound();
cat.makeSound();

//ES6 getter and setter

class rectangle{
    constructor(height,width)
    {
        this.height=height;
        this.width=width;
    }
    //getter
    get area(){
        return this.calcarea();
        }
        set newheight(value)
        {
            this.height=value;

        }
        //method
        calcarea()
        {
            return this height*this.width;
   
     }
}

const square = new rectangle(10,10);
console.log(square.area);//100

square.newheight=22;

/* 
Create a transport station (TS)(from busses)
the ts shold have busses whitch are part of the Bus class.
Each bus shold have difrent number (line number),color,
number of passanger and ticket price.
passanger shold be part od passanger class.
each bus shold have different status e.g: movi,broken,
status of passanger at the moment,pick up passao=nger ,
passanger leaving etc.

Put the in array print them on console log whit status
*/