/*$.ajax({
    url:'API_URL',
    type: 'METHOD',//GET,POST, PUT, DELETE = CRUD
    data:'username=user1',
    contentType:"application/json",//MIME type
    dataType:'jsonp',//html,text,json,jsonp
    success: function(data){
    //what to happen when success
    },
    error:function(e) {
    //called when there is an error
    }

});
*/
let apiEndPoint = 'https://jsonplaceholder.typicode.com/';
$("document").ready(function () {
    getToDos();
});

function getToDos() {
    let uri = 'todos';

    $.ajax({

        url: apiEndPoint + uri,//http://www.recipepuppy.com/;
        method: "GET",
        dataType: "json",
        withCredentials: true,
        success: function (data) {
            printTodos(data);
        },
        error: function (e) {
            console.log(e);
        }
    });
}
function printTodos(listofTodos) {
    console.log(listofTodos);
    for (let i = 0, ilen = listofTodos.length; i < ilen; i++) {
        //for(let i=0;i< listoftodos.lenght;i++)
        console.log(i)
        $("#existingTodos > ul").append('<li> userId:' + listofTodos[i].userId + ',title:' + listofTodos[i].title + '</li>');

    }
}


/*
username = user1
firstName=John
lastName=Doe
dob=11/11/111

2019-01-09
*/