//  let a=10;
//  function changeA()
//  {
//      a=14;//vrednosta e 14
//      console.log(a);
//      return a;
//  }
//  function changeAB()
//  {
//      a=20;//vrednosta ostanuva samo 20
//      console.log(a);
//      return a;
//  }
//  console.log(a,changeA(),changeAB());// pecati 14 20 pa 10
//  //so return a se pecati 10,14 20 po redosled 
//  // consol.log(a); pecati 10 
//  //changeA(); pecati 14
//  //changeAB();pecati 20
//  // so povik na change a ke ispecati vrednost 20

//  // Async code

//  function a()
//  {
//      setTimeout(() => { //so ovaa funkcija se odolgovlekuva negovoto izvrsuvanje da se izvrsi posledno
//         console.log('a');   //return 10; 
//      },200)
//      //return 20;
//  }
//  function b()
//  {
//      console.log('b'); //return 50;
//  }
//  a();
//  b();//iako e povikano prven a ke go ispecati prven b pa potoa a 

 
// //  function a()
// //  {
// //      setTimeout(() => { //so ovaa funkcija se odolgovlekuva negovoto izvrsuvanje da se izvrsi posledno
// //         c=10;   //return 10; 
// //      },200)
// //     return 20;
// //  }
// //  function b()
// //  {
// //     return 50;
// //  }
// //  let c =a();
// //  c=b();
// //  console.log(c);


// function a()
// {
//     setTimeout(() => { //so ovaa funkcija se odolgovlekuva negovoto izvrsuvanje da se izvrsi posledno
//        return 10; 
//     },200)
//     return 20;
// }
// function b()
// {
//     return 50;
// }
// setTimeout(() => { 
//     console.log(c); 
//  },100);
//  let c=a();
//  c=b();
// console.log(c);
// setInterval(() => {
//     a=4;
// }, 10);
// setInterval(() => {
//     console.log(c);
// }, 1);

//gresno poradi innertHTML za vo broser
// let button=document.createElement('button');
// button.innerHTML='clickMe';
// document.body.innerHTML(button); // treba da se promeni append za da raboti

// let a=document.querySelector('button').addEventListener('click',()=>{
//     console.log('clicked');
//     return 10;
// })
// console.log(a);

//tocno resenie za da funkcionira
// let button=document.createElement('button');
// button.innerHTML='clickMe';
// document.body.append(button);

// let a=document.querySelector('button').addEventListener('click',()=>{
//     console.log('clicked');
//     return 10;
// })
// console.log(a);

// let button=document.createElement('button');
// button.innerHTML='ClickMe';
// button.setAttribute('class','our-button');
// button.setAttribute('id','asd');


// button.addEventListener('click',()=>{
//     console.log('clicked');
//     return 10;
// })
// document.body.appendChild(button);
// <button class="our-button" id="asd">clickMe</button>

//Use the image from url:http//tiny.cc/zfim2y
//Using setInterval or /and setTimeout to make the Robot to move from far left to far right on the screen and stop there.
//The movement shold be done from a JS function, one move by a time.
//Add two buttons,(left,right)=when user click on the robot will move one step left(back) or one step right(forward).

let position=0;
let step=10;//10%

//shold move the robot to the right for the "STEP" value
function moveRight()
{
    applyPositionToRobot();
}

//Should move the robot to the left for the "STEP" value
function moveLeft()
{
   if(position>0)
       
 applyPositionToRobot(position);

}

//will call set ot functions for evety 1 secund
let moveIntervaller=setInterval(()=>{
   moveRight();//by defult move it to the right
    isEnd();//Check is end of the movement - it means the position had reached 100% of the screen

},1000);//1000=1s

//it will apply the position(style) to the robot
function applyPositionToRobot()
{
 document.querySelector('img').style='position: relative; left:${position}';
 //.styl='position:relative;left:'+position+'';
}

//will check is end the screen it will stop the movement
function isEnd()
{
    if(position>=max)
    {
        clearInterval(moveIntervaller);
    }

}


document.getElementById("buttonLeft").addEventListener('click',(e)=>{
    {
        if(applyPositionToRobot==37){
            position -=2;
            applyPositionToRobot.style.moveRight=position +'px';
            if(position <=0)
            {
                position +=2;
            }
        }
       }
});
document.getElementById("buttonRight").addEventListener('click',(e)=>{
    {
        if(applyPositionToRobot==37){
            position -=2;
            applyPositionToRobot.style.moveRight=position +'px';
            if(position <=0)
            {
                position +=2;
            }
        }
       }
       
});

//Promises 

new Promise(function (resolce,reject){...}); 
//mozze da gi imame i dvata za da funkcionira mozeme i samo prviot ke funkcionira dokolku go ostaime vtoriot ke go zeme kako prv

Promise.then(
    script=>alert(`${script.src}is loaded!`),
    error =>alert(`Error:${error.message}`)
    
    
);
var promise1=new promise(function(resolve,reject){
    setTimeout(function(){
        resolve('foo');
    },300);
    
});
promise1.then(function(value){
    console.log(value);
    //expected output:"foo"
}),
function(error){
    console.log(error);
}

