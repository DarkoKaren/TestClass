//object destructing / destruction
//destrakcti na eden objekt da dodelime vrednosti po struktura treba da e ista po strukturata na objektot
//
let someArray=[10,20,30];
var first=someArray[0];
var second=someArray[1];
var third=someArray[0];


/// po prakticna primena od ova gore e 

let [first,second,third]=someArray; // let var const e isto -

let [,,third]=someArray;//third=30;

let secondArray =[1,2,[3],5];
let[,,[thirdItem]]=secondArray;//za da ima cista vrednost 3  , i kako se definirani vrednostite tolku prazni mesta odnosno zapirki
console.log(thirdItem);

let secondArray =[1,2,[3,10,20],5];
let[,,[thirdItem]]=secondArray;
console.log(thirdItem);

let[indexOne,indexTow,...taill]=secondArray;
//indexOne=1,indexTow=2,tail=[[3,10,20],5]

//object

let a={name:"John"};
let b={name:"jane"};

let {name:nameA}=a;
let {name:nameB}=b;

console.loog(nameA,nameB);

var {foo,bar}={foo:'lorem', bar:'ipsum'};
//import{UserClass} from"../../files/user.class.js";

//userClass.getUser(userId);

function returnMultipleValues()
{
    return [1,2];
}
//oldway
let result = returnMultipleValues();

let a=result[0];
let b=result[1];

//newWay

let [a,b]=returnMultipleValues();

function returnMultipleValues(){

    return{
        foo:1,
        bar:2
    };
}
let {foo,bar}=returnMultipleValues();
let {foo: valueOfFoo , bar:valuesOfBar }=returnMultipleValues();

//pre defined- defULT VALUES

const [x=3, y=x]=[];// X=3;Y=3
const [x=3, y=x]=[7];// X=7;Y=7
const [x=3, y=x]=[7 ,2];// X=7;Y=2

const{prop: x=123}={};//x=123

//computed property
const FOO='foo';
const {[FOO]:f}={foo: 123}; //f=123

let m = {foo:123};
m[FOO]//123


let f = m{foo:123};
const {[FOO]:f}=m;//f=123


/*
1.write a function called displayStudentaaInfo which accepts an object and returns the string
"Your full name is" concatenated with the value of the first key and a space and
the value of the last key. See if you can destructure this object inside of the function
*/
let o={firstName:'john',lastName:'Doe'};
//your name is John Doe



function returnMultipleValues(){

    return{
        'your name is': "",
        name:'John',
        last:'Doe'
    };
}
let {name,last}=returnMultipleValues();

/*2.
Using destruction get value "C" from the object and assing it to a variable
let o={prop:"hello", prop2:{ prop2:{nested:['a','b','c']}}} 
*/

var {
    prop:x,
    prop2:{
        prop2:{
            nested:[,,b]
        }
    }
}={prop:"hello", prop2:{ prop2:{nested:['a','b','c']}};
    console.log(b);


    /*
    3.using map from array (array.map), print in console log first and las name of each person in the array
    using object destruvting

    let names=[
        ['mary','williams'],
        ['john','cooper'],
        ['jane',collins'],
        ['george','noble']
    ]
    in console
    */

names.map(([firstName,lastName])=>{
    console.log(firstName,lastName)
})



    /*
    4.get the item before the last form the following array using object destruction
    let n=1000;
    let arr = array.apply(null,{length:N}.map(number.call,number));
    (we need the value of arr[999]) 
    */
   let N=1000;
    let arr = Array.apply(null,{length:N}).map(Number.call,Number);
arr.reverse();
let [,n998]=arr;//resenie za 4 zadaca primer eden tipe 1one


let  otherArr=Array.reverse();
let [,n998]=otherArr;//primer 2 tipe 2






    let 0={name:'john',last:'doe',age:'33'};
delete o.age;//za brisenje 


/*
5.Using the object below remove the property "nested" using object.keys,values,
for loop etc

let o={prop:'hello',prop2:{prop2{mested:['a','b','c']}}};
*/