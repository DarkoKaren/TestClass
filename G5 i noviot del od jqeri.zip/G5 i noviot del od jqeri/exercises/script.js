//Task1
//Declare a variable a.
//Assign the variable with the value of 7.
//Declare and asign a variable b with the value of 8.
//Declare a variable c and asign it the value of a + b.
//Print the value in the console.


//Task2
//Declare a variable x.
//Assign the value to 7.
//Assign the value to 6.
//Print the value of x. 
//What is the value of x.
//Declare again the variable x. Is this ok?


//Task3
//Declare and asign an integer variable.
//Declare and asign a boolean variable.
//Declare and asign a string variable.
//Use the typeof operator to check the types of all assigned variables.


//Task4
//Declare 2 variables x and y and set them to 10 and 3.
//Declare and asign a variable that would be the result of division of 10 and 3.
//Declare and asign a variable that would be the whole part of the division of 10 and 3.
//Declare and asign a variable that would be the remainder of the division of 10 and 3.


//Task5
//Declare and assign an array of 6 integers. Ex 5,6,15,42.
//Declare and assign an array of strings. Ex Orce Viktor Stojanco Dejan
//Print the first value of each array.
//Print the arrays.
//Change the values of the first element in both arrays.
//Assign a value to the 100 th member of the first array.
//Print how many elements the array has? 
//What is the value of the 99th element in the array.
//Write an example of push.
//Write an example of pop.
//What is the value of the 1000th element in both arrays?


//Task6
//Write a JavaScript program that will convert denars to euros.
//One euro is 61.5 denars.


//Task7
//Write a JavaScript program that will calculate the age of the  
//user if the user inputs his birth year.


//Task8
//Write a JavaScript program where the program takes a random integer between 
//1 to 10. If the user input matches this 10 numbers, print them with words, else 
//print invalid input. Example if input is 4, output should be "four". If something else 
//is given as input, program should alert "invalid input". (Use switch)


//Task9
//Write a JavaScript program to find the area of a triangle where lengths of the three of its sides are 5, 6, 7.
//Formula for calculating area of the triangle = 
//square root of halfperimeter * (halfperimeter - side1) * (halfperimeter - side2) * (halfperimeter - side3)
//Formula for calculating perimeter = side1 + side2 + side3.


//Task10
//Write a JavaScript program that will find the sum of all items in the given array,  
//make it dynamic, so the result will change if the array is changed. 


//Task11
//Write a JavaScript program that will find the sum of all positive numbers in the array.


//Task12
//Write javascript program that will take the items from a given array 
//and make new aray with the same items in revers order.


//Task13
//Write javascript program that will find the biggest and 
//the smallest number in the array.


//Task14
//Write javascript program that will find the average value 
//from the all the item values in the given array.


//Task15
//Write javascript program that will find all numbers divisable 
//by 7 and 3 in a given array.


//***BONUS TASKS***


//Write a JavaScript program to remove duplicate items from an array.


//Write a JavaScript program which accept a number as input and insert dashes (-) between 
//each two odd numbers. For example if you accept 025468 the output should be 0-254-6-8.


//Write a JavaScript program which prints the elements of the following array. Note: Use nested for loops.
//Sample array: var a = [[1, 2], [8, 11], [7, 0, 7, 27], [7, 4, 28, 14], [3, 10, 26, 7]];