/*
var student = new Object();

student.name = 'Stojancho';
student.age = 26;
student.id = 1;

student.alertInfo = function () {
	alert(this.name + ' ' + this.age + ' ' + this.id);
};

student.alertInfo();

//console.log(student);
//alert(student.name + ' ' + student.age + ' ' + student.id);
//alert(student.name, student.age, student.id);
//alert(student.name + student.age + student.id);
*/

//literal notation

let student = {
	name : 'Viktor',
	age : 27,
	id : 2,

	alertInfo : function() {
		alert(this.name + ' ' + this.age + ' ' + this.id);
	}

};

//student.alertInfo();

student["alertInfo"]();//same as above

student.getAge = function() {
	return this.age;
}

let studentAge = student.getAge();
console.log(studentAge);

delete student.id;
console.log('student.id: ' + student.id);