/*var number = 9;
var counter = 0;

for (var i = 2; i <= (number / 2); i++) {
	if (number % i === 0) {
		alert('Number ' + number + 'is not prime');
		counter++;
		break;
	}
}

if (counter === 0) {
	alert('Number ' + number + 'is prime');
}
*/

/*
var primeCounter = 0;

for (var number = 2; primeCounter < 2; number++) {
	//var number = 9; not need anymore
	var counter = 0;

	for (var i = 2; i <= (number / 2); i++) {
		if (number % i === 0) {
			//alert('Number ' + number + 'is not prime');
			counter++;
			break;
		}
	}

	if (counter === 0) {
		alert('Number ' + number + 'is prime');
		primeCounter++;
	}
}
*/

/*
function isPrime(number) {
	//var number = 9;
	var counter = 0;

	for (var i = 2; i <= (number / 2); i++) {
		if (number % i === 0) {
			alert('Number ' + number + 'is not prime');
			counter++;
			break;
		}
	}

	if (counter === 0) {
		alert('Number ' + number + 'is prime');
	}
}*/

//isPrime(7);
//isPrime(345);
//isPrime(15);


var primeCounter = 0;

for (var number = 2; primeCounter < 10; number++) {
	//var number = 9; not need anymore
	var isNumberPrime = isPrime(number);

	if (isNumberPrime === true) {
		alert('Number ' + number + 'is prime');
		primeCounter++;
	}
}

function isPrime(number) {
	//var number = 9;
	//var counter = 0;

	for (var i = 2; i <= (number / 2); i++) {
		if (number % i === 0) {
			//alert('Number ' + number + 'is not prime');
			return false;
			//counter++;
			//break;
		}
	}

	//if (counter === 0) {
		//alert('Number ' + number + 'is prime');
		return true;
	//}
}