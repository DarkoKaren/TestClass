/*function getLottoCombinations(totalBalls, drawnBalls) {
	var result;

	var totalBallsFactoriel = 1;

	var i = 1;
	while(i <= totalBalls) {
		totalBallsFactoriel = totalBallsFactoriel * i;
		i++;
	}

	var drawnBallsFactoriel = 1;

	var i = 1;
	while(i <= drawnBalls) {
		drawnBallsFactoriel = drawnBallsFactoriel * i;
		i++;
	}
	
	var minusFactoriel = 1;
	var minusResult = totalBalls - drawnBalls;

	var i = 1;
	while(i <= minusResult) {
		minusFactoriel = minusFactoriel * i;
		i++;
	}
	
	result = totalBallsFactoriel / (drawnBallsFactoriel * minusFactoriel);

	return result;
}

var lottoCombinations = getLottoCombinations(36, 6);
console.log(Math.round(lottoCombinations));
*/

/*function calculateFactoriel(number) {
	var result = 1;

	var i = 1;
	while(i <= number) {
		result = result * i;
		i++;
	}

	return result;
}*/
/*
function getLottoCombinations(totalBalls, drawnBalls) {
	var result;

	var totalBallsFactoriel = calculateFactoriel(totalBalls);

	var drawnBallsFactoriel = calculateFactoriel(drawnBalls);
	
	var minusResult = totalBalls - drawnBalls;
	var minusFactoriel = calculateFactoriel(minusResult);
	
	result = totalBallsFactoriel / (drawnBallsFactoriel * minusFactoriel);

	return result;
}

var lottoCombinations = getLottoCombinations(36, 6);
console.log(Math.round(lottoCombinations));
*/

//let vs var
/*console.log(i);//undefined
for (var i = 0; i < 10; i++) {
	console.log(i);
}
console.log('Outside for: ' + i);//10*/

function test() {
	//console.log(i);//undefined
	var x;
	//const testConst;//error
	const testConst = 7;
	//testConst = 9;//error
	{
		var y;
		let z;
	}
	console.log(z);
	console.log(y);

// 	for (var i = 0; i < 10; i++) {
// 		console.log(i);
// 	}
// console.log('Outside for: ' + i);
}

//console.log(i);//Uncaught ReferenceError: i is not defined
for (let i = 0; i < 10; i++) {
	console.log(i);
}
console.log('Outside for: ' + i);//10