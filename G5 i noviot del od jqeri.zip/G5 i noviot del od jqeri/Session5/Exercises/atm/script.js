var balance = 5000;

function getBalance() {
	alert("Your current balance is: " + balance);
	atm();
}

function makeDeposit() {
	var deposit = parseInt(prompt("Please enter the amount of money you want to deposit to you account."));

	balance += deposit;
	atm();
}

function makeWithdrawal() {
	var withdraw = parseInt(prompt("How much money you want to withdraw: "));

	balance -= withdraw;
	atm();
}

function exit() {
	window.close();
}

function atm() {

	var input = parseInt(prompt("make your selection: "));

	switch(input) {

		case 1: 
			getBalance();
			break;
		case 2: 
			makeDeposit();
			break;
		case 3: 
			makeWithdrawal();
			break;
		case 4: 
			exit();
			break;	
		default:
			alert("Invalid input!");		
	}
} 

atm();
