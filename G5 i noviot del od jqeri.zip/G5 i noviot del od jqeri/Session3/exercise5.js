var inputs = [];
var alreadyEntered = false;

while (!alreadyEntered) {
	var input = prompt('Enter number: ');

	for (var i = 0; i < inputs.length; i++) {
		if (inputs[i] === input) {
			alert("Already entered!");
			alreadyEntered = true;
			break;
		}
	}

	inputs.push(input);
}