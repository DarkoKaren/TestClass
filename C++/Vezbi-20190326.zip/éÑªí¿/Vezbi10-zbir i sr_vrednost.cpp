#include <iostream.h>
int zbir(int a, int b); //deklaracija na funkcija

float sr_vr(float br1, float br2); 
void main(){
	/* int x,y;
	cout<<"Vnesi go X:";
	cin>>x;
	cout<<"Vnesi go Y:";
	cin>>y;
	int zbirXY=zbir(x,y); //povik na funkcija
	cout<<"Zbirot na X i Y e "<<zbirXY;
	*/
	float a1, a2;
	cout<<"Vnesi go a1:";
	cin>>a1;

	cout<<"Vnesi go a2:";
	cin>>a2;

	float sr_vrednost = sr_vr(a1,a2); //povik na f-ja
	cout<<"Sredna vrednost na a1 i a2 e "<<sr_vrednost;

	cin>>a1;
}
// definicija (KOD) na funkcija
float sr_vr(float br1, float br2){
	return 1.0*(br1+br2)/2;
}

int zbir(int a, int b){
	//vnattresna promeniva
	int suma=0;
	suma=a+b;
	//povratna vrednost na f-jata
	//return 189;
	return suma;
}

